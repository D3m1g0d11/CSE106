import numpy as np
from numpy import linalg

def array1():
    print("Array 1: 4x2 matrix from 2 to 10:")
    arr1 = np.arange(2, 10, 1).reshape(4, 2)
    print(arr1)
    print("\n")

def array2():
    print("Array 2 8x8 Matrix  Checkerboard")
    arr2 = np.zeros((8, 8))
    arr2[::2, 1::2] = 1
    arr2[1::2,::2] = 1
    print(arr2)
    print("\n")

def array3():
    print("Array 3 Unique List: ")
    List = [10, 20, 10, 30, 20, 40, 20, 20, 10, 30, 0, 50, 10]
    print(np.unique(List))
    print("\n")

def array4():
    List = [6, 75, 9, 82, 36, 42, 59, 3, 52, 1, 32, 68, 93, 4, 27, 85, 0, -3, 57]
    print("Values of List bigger than 37: ")
    List = np.array(List)
    List = List[List>37]
    print(List)
    print("\n")

def array5():
    List = [0, 12, 45.21 ,34, 99.91]
    List = np.array(List)
    print("Celsius to Fahrenheit: ")
    #List = List[(]
    print((List * 1.8) + 32)
    print("\n")

def matCal():
    A = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
    B = np.array([[3, 1, 4], [2, 6, 1], [2, 9, 7]])

    c = np.add(A, B)
    d = np.cross(A, B)
    #Determinant of A
    e = np.linalg.det(A)
    f = np.linalg.inv(B)
    g = np.linalg.eigvals(A)
    #EigenValue of of B
    print("A + B = ")
    print(c)
    print("A * B = ")
    print(d)
    print("Determinant of A:")
    print(e)
    print("Inverse of B: ")
    print(f)
    print("Eigenvalues of A: ")
    print(g)

if __name__ == "__main__":
    array1()
    array2()
    array3()
    array4()
    array5()
    matCal()