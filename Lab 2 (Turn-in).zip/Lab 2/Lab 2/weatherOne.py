import pandas as pd
import datetime

def maxActualPrecipitation(w):
    prep = w.iloc[0]
    for index, i in w.iterrows():
        if(float(i["actual_precipitation"]) >= prep["actual_precipitation"]):
            prep = i
    
    print("Highest prepicipitaion day: ")
    print(prep.date)
    print(w.actual_precipitation.max())

def aveMaxTemp(w):
    july = (w["date"] > "07-01-2014") & (w["date"] <= "07-31-2014")
    july = w.loc[july]
    julyMean = july.actual_max_temp.mean() 
    print(julyMean)

def hottestDays(w):
    hot = w.iloc[0]
    print(hot.date)
    for index, i in w.iterrows():
        if(float(i["actual_max_temp"]) == hot["actual_max_temp"]):
            hot = i
            print(hot.date)


def octoberRain(w):
    j = 0
    selections = (w["date"] > "10-01-2014") & (w["date"] <= "10-31-2014")
    selections = w.loc[selections, "actual_precipitation"]
    print("It rained this much in October: ")
    print(selections.sum())

def extremeDays(w):
    found = False
    print("Days below 60 and above 90: ")
    for index, i in w.iterrows():
        if(i["actual_min_temp"] < 60 and i["actual_max_temp"] > 90):
           found = True
           print(i.date)
    
    if found == False:
        print("No day found")

def main():
    path = "/Users/John Biton/College Code/CSE S23/CSE 106/Lab 2/Lab 2/"
    weather_data = pd.read_csv(path + "weather_data.txt")
    print(weather_data)
    weather_data["date"] = pd.to_datetime(weather_data["date"])
    
    
    print("\n3a.")
    maxActualPrecipitation(weather_data)

    print("\n3b.")
    print("Average July Temp: ")
    aveMaxTemp(weather_data)
    
    print("\n3c.")
    print("Record Days: ")
    hottestDays(weather_data)

    print("\n3d.")
    print("October Rain: ")
    octoberRain(weather_data)

    print("\n3e.")
    print("Extreme Temperature Changes: ")
    extremeDays(weather_data)

if __name__ == "__main__":
    main()
