import pandas as pd
import datetime
import matplotlib.pyplot as plt

def lineGraph(w):
    w["actual_max_temp"].plot(color = "red")
    w["actual_min_temp"].plot(color = "blue")
    plt.show()

def histo(w):
    w["actual_precipitation"].plot(kind = 'hist')
    plt.show()

def main():
    path = "/Users/John Biton/College Code/CSE S23/CSE 106/Lab 2/Lab 2/"
    weather_data = pd.read_csv(path + "weather_data.txt")
    print(weather_data)
    weather_data["date"] = pd.to_datetime(weather_data["date"])

    lineGraph(weather_data)    
    histo(weather_data)    

if __name__ == "__main__":
    main()
